const express = require("express");
const router = express.Router();
const {
  registerForEvent,
  getMyRegistrations,
  cancelRegistration,
  getRegistrationsForEvent,
} = require("../controllers/registrationController");
const { protect } = require("../middleware/auth");

router.post("/", protect, registerForEvent);
router.get("/me", protect, getMyRegistrations);
router.delete("/:id", protect, cancelRegistration);
router.get("/event/:eventId", protect, getRegistrationsForEvent);

module.exports = router;
