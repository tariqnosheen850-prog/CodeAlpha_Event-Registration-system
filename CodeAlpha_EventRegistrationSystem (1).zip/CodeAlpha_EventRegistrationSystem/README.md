# CodeAlpha_EventRegistrationSystem

**CodeAlpha Backend Development Internship — Task 1: Event Registration System**

A REST API backend built with **Express.js** and **Sequelize** (works with SQLite out of the box, or PostgreSQL/MySQL by changing one config value) for creating events, listing them, and letting users register, view, and cancel their registrations. Includes JWT authentication with two roles: `user` (attendee) and `organizer` (can create/manage events).

## Features
- User registration & login with JWT authentication
- Two roles: `user` and `organizer`
- Organizers can create, update, and delete events
- Anyone can view the event list and event details
- Logged-in users can register for an event, view their own registrations, and cancel them
- Organizers can view who registered for their events
- Event capacity limits (optional per event)

## Tech Stack
- Node.js + Express.js
- Sequelize ORM — SQLite by default (zero setup), switch to PostgreSQL/MySQL by editing `.env`
- JWT (jsonwebtoken) for auth
- bcryptjs for password hashing

## Project Structure
```
CodeAlpha_EventRegistrationSystem/
├── config/
│   └── database.js        # Sequelize connection (SQLite or PostgreSQL)
├── models/
│   ├── User.js
│   ├── Event.js
│   ├── Registration.js
│   └── index.js            # associations
├── middleware/
│   └── auth.js              # JWT protect + organizerOnly
├── controllers/
│   ├── authController.js
│   ├── eventController.js
│   └── registrationController.js
├── routes/
│   ├── authRoutes.js
│   ├── eventRoutes.js
│   └── registrationRoutes.js
├── server.js
├── .env.example
└── package.json
```

## Setup

```bash
git clone https://github.com/tariqnosheen850-prog/CodeAlpha_EventRegistrationSystem.git
cd CodeAlpha_EventRegistrationSystem
npm install
cp .env.example .env
# edit .env if you want to change the JWT secret or switch to PostgreSQL
npm start
```

The server runs on `http://localhost:5000` by default. A SQLite database file (`database.sqlite`) is created automatically — no separate database server needed.

### Using PostgreSQL instead of SQLite
In `.env`, set:
```
DB_DIALECT=postgres
DB_HOST=localhost
DB_PORT=5432
DB_NAME=event_registration
DB_USER=postgres
DB_PASSWORD=postgres
```
No code changes needed — `config/database.js` reads these values automatically.

## API Endpoints

### Auth
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register as `user` or `organizer` |
| POST | `/api/auth/login` | Public | Log in, returns a JWT |
| GET | `/api/auth/me` | Logged-in | Get current user profile |

Register body:
```json
{ "name": "Ali Raza", "email": "ali@example.com", "password": "secret123", "role": "organizer" }
```

### Events
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/api/events` | Public | View event list |
| GET | `/api/events/:id` | Public | View event details + spots left |
| POST | `/api/events` | Organizer | Create an event |
| PUT | `/api/events/:id` | Organizer (owner) | Update an event |
| DELETE | `/api/events/:id` | Organizer (owner) | Delete an event |

Create event body:
```json
{ "title": "Tech Meetup", "description": "Networking night", "location": "Islamabad", "date": "2026-10-15T18:00:00Z", "capacity": 50 }
```

### Registrations
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/registrations` | Logged-in user | Register for an event (`{ "eventId": 1 }`) |
| GET | `/api/registrations/me` | Logged-in user | View my registrations |
| DELETE | `/api/registrations/:id` | Logged-in user (owner) | Cancel a registration |
| GET | `/api/registrations/event/:eventId` | Organizer (owner) | View attendees for one of my events |

All logged-in routes require the header:
```
Authorization: Bearer <your_jwt_token>
```

## Data Model
- **User** — name, email, password (hashed), role (`user`/`organizer`)
- **Event** — title, description, location, date, capacity, organizerId (FK → User)
- **Registration** — userId (FK → User), eventId (FK → Event), status (`confirmed`/`cancelled`)

A Registration links one User to one Event (many-to-many between User and Event, through Registration), which is how "view/cancel my registrations" and "view attendees of my event" both work.

## Submission Checklist (CodeAlpha)
1. `git init && git add . && git commit -m "Task 1: Event Registration System backend"`
2. Create a GitHub repo named **CodeAlpha_EventRegistrationSystem** and push:
   ```bash
   git remote add origin https://github.com/tariqnosheen850-prog/CodeAlpha_EventRegistrationSystem.git
   git branch -M main
   git push -u origin main
   ```
3. Post on LinkedIn about completing the task, tag **@CodeAlpha**, and include the GitHub repo link.

## Notes
- SQLite is used by default purely so the project runs with zero external setup for grading; it is a real relational database and the code is 100% compatible with PostgreSQL — just flip `DB_DIALECT` in `.env`.
- Passwords are hashed with bcrypt before storage; never stored in plain text.
