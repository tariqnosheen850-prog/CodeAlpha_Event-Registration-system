const jwt = require("jsonwebtoken");
const { User } = require("../models");

// Verifies the JWT sent in the Authorization header and attaches req.user
exports.protect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Not authorized, no token provided" });
    }

    const token = authHeader.split(" ")[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findByPk(decoded.id, {
      attributes: { exclude: ["password"] },
    });
    if (!user) {
      return res.status(401).json({ message: "User no longer exists" });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: "Not authorized, invalid or expired token" });
  }
};

// Restricts a route to organizers only. Use after `protect`.
exports.organizerOnly = (req, res, next) => {
  if (req.user.role !== "organizer") {
    return res.status(403).json({ message: "Only event organizers can perform this action" });
  }
  next();
};
