const { Registration, Event, User } = require("../models");

// POST /api/registrations - submit a registration form (logged-in user registers for an event)
exports.registerForEvent = async (req, res) => {
  try {
    const { eventId } = req.body;
    if (!eventId) return res.status(400).json({ message: "eventId is required" });

    const event = await Event.findByPk(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    // Check for an existing registration (active or cancelled) for this user+event
    let registration = await Registration.findOne({
      where: { userId: req.user.id, eventId },
    });

    if (registration) {
      if (registration.status === "confirmed") {
        return res.status(409).json({ message: "You are already registered for this event" });
      }
      // Re-activate a previously cancelled registration
      registration.status = "confirmed";
      await registration.save();
      return res.status(200).json({ message: "Registration re-confirmed", registration });
    }

    // Enforce capacity if set
    if (event.capacity) {
      const confirmedCount = await Registration.count({
        where: { eventId, status: "confirmed" },
      });
      if (confirmedCount >= event.capacity) {
        return res.status(400).json({ message: "This event is fully booked" });
      }
    }

    registration = await Registration.create({ userId: req.user.id, eventId });
    res.status(201).json({ message: "Registered successfully", registration });
  } catch (err) {
    res.status(500).json({ message: "Registration failed", error: err.message });
  }
};

// GET /api/registrations/me - view my registrations
exports.getMyRegistrations = async (req, res) => {
  try {
    const registrations = await Registration.findAll({
      where: { userId: req.user.id },
      include: [{ model: Event }],
      order: [["createdAt", "DESC"]],
    });
    res.json({ count: registrations.length, registrations });
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch registrations", error: err.message });
  }
};

// DELETE /api/registrations/:id - cancel a registration
exports.cancelRegistration = async (req, res) => {
  try {
    const registration = await Registration.findByPk(req.params.id);
    if (!registration) return res.status(404).json({ message: "Registration not found" });
    if (registration.userId !== req.user.id) {
      return res.status(403).json({ message: "You can only cancel your own registrations" });
    }

    registration.status = "cancelled";
    await registration.save();
    res.json({ message: "Registration cancelled", registration });
  } catch (err) {
    res.status(500).json({ message: "Failed to cancel registration", error: err.message });
  }
};

// GET /api/registrations/event/:eventId - organizer views who registered for their event
exports.getRegistrationsForEvent = async (req, res) => {
  try {
    const event = await Event.findByPk(req.params.eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });
    if (event.organizerId !== req.user.id) {
      return res.status(403).json({ message: "You can only view registrations for your own events" });
    }

    const registrations = await Registration.findAll({
      where: { eventId: req.params.eventId },
      include: [{ model: User, attributes: ["id", "name", "email"] }],
    });
    res.json({ count: registrations.length, registrations });
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch registrations", error: err.message });
  }
};
