const { Event, Registration, User } = require("../models");

// GET /api/events  - view event list
exports.getEvents = async (req, res) => {
  try {
    const events = await Event.findAll({
      order: [["date", "ASC"]],
      include: [{ model: User, as: "organizer", attributes: ["id", "name", "email"] }],
    });
    res.json({ count: events.length, events });
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch events", error: err.message });
  }
};

// GET /api/events/:id - view event details
exports.getEventById = async (req, res) => {
  try {
    const event = await Event.findByPk(req.params.id, {
      include: [{ model: User, as: "organizer", attributes: ["id", "name", "email"] }],
    });
    if (!event) return res.status(404).json({ message: "Event not found" });

    const confirmedCount = await Registration.count({
      where: { eventId: event.id, status: "confirmed" },
    });

    res.json({
      event,
      confirmedRegistrations: confirmedCount,
      spotsLeft: event.capacity ? Math.max(event.capacity - confirmedCount, 0) : null,
    });
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch event", error: err.message });
  }
};

// POST /api/events - create event (organizer only)
exports.createEvent = async (req, res) => {
  try {
    const { title, description, location, date, capacity } = req.body;
    if (!title || !date) {
      return res.status(400).json({ message: "title and date are required" });
    }

    const event = await Event.create({
      title,
      description,
      location,
      date,
      capacity,
      organizerId: req.user.id,
    });

    res.status(201).json({ event });
  } catch (err) {
    res.status(500).json({ message: "Failed to create event", error: err.message });
  }
};

// PUT /api/events/:id - update event (organizer who owns it only)
exports.updateEvent = async (req, res) => {
  try {
    const event = await Event.findByPk(req.params.id);
    if (!event) return res.status(404).json({ message: "Event not found" });
    if (event.organizerId !== req.user.id) {
      return res.status(403).json({ message: "You can only edit your own events" });
    }

    const { title, description, location, date, capacity } = req.body;
    await event.update({ title, description, location, date, capacity });
    res.json({ event });
  } catch (err) {
    res.status(500).json({ message: "Failed to update event", error: err.message });
  }
};

// DELETE /api/events/:id - delete event (organizer who owns it only)
exports.deleteEvent = async (req, res) => {
  try {
    const event = await Event.findByPk(req.params.id);
    if (!event) return res.status(404).json({ message: "Event not found" });
    if (event.organizerId !== req.user.id) {
      return res.status(403).json({ message: "You can only delete your own events" });
    }

    await event.destroy();
    res.json({ message: "Event deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete event", error: err.message });
  }
};
