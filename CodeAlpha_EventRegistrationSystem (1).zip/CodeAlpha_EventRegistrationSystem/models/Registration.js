const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

// Links a User to an Event they registered for
const Registration = sequelize.define(
  "Registration",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    status: {
      type: DataTypes.ENUM("confirmed", "cancelled"),
      defaultValue: "confirmed",
    },
  },
  {
    timestamps: true,
    indexes: [
      // A user can only have one active registration record per event
      {
        unique: true,
        fields: ["userId", "eventId"],
      },
    ],
  }
);

module.exports = Registration;
