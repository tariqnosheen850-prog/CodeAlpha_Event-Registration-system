const sequelize = require("../config/database");
const User = require("./User");
const Event = require("./Event");
const Registration = require("./Registration");

// A User can have many Registrations; a Registration belongs to one User
User.hasMany(Registration, { foreignKey: "userId", onDelete: "CASCADE" });
Registration.belongsTo(User, { foreignKey: "userId" });

// An Event can have many Registrations; a Registration belongs to one Event
Event.hasMany(Registration, { foreignKey: "eventId", onDelete: "CASCADE" });
Registration.belongsTo(Event, { foreignKey: "eventId" });

// Many-to-many convenience: Users <-> Events through Registration
User.belongsToMany(Event, { through: Registration, foreignKey: "userId" });
Event.belongsToMany(User, { through: Registration, foreignKey: "eventId" });

// An Event optionally belongs to an organizer (User)
User.hasMany(Event, { foreignKey: "organizerId" });
Event.belongsTo(User, { foreignKey: "organizerId", as: "organizer" });

module.exports = { sequelize, User, Event, Registration };
